import pytest
from trace360.core.control_loader import ControlLoader
from trace360.core.evaluator import Evaluator
from trace360.core.models import ControlDefinition

def test_load_control(tmp_path):
    # Create a temporary control file
    control_dir = tmp_path / "controls"
    control_dir.mkdir()
    gcp_dir = control_dir / "gcp"
    gcp_dir.mkdir()
    
    control_file = gcp_dir / "test.yaml"
    control_file.write_text("""
id: TEST_ID
name: Test Control
connector: gcp
operation: test_op
scope:
  key: value
expected:
  status: ok
""")
    
    loader = ControlLoader(str(control_dir))
    control = loader.load_control("gcp/test.yaml")
    
    assert control.id == "TEST_ID"
    assert control.connector == "gcp"
    assert control.scope["key"] == "value"

def test_evaluate_pass():
    control = ControlDefinition(
        id="T1", name="N1", connector="c1", operation="o1",
        expected={"status": "ok"}
    )
    result = {"status": "ok", "other": "data"}
    assert Evaluator.evaluate(control, result) == "PASS"

def test_evaluate_fail():
    control = ControlDefinition(
        id="T1", name="N1", connector="c1", operation="o1",
        expected={"status": "ok"}
    )
    result = {"status": "error"}
    assert Evaluator.evaluate(control, result) == "FAIL"

def test_evaluate_missing_key():
    control = ControlDefinition(
        id="T1", name="N1", connector="c1", operation="o1",
        expected={"status": "ok"}
    )
    result = {"different_key": "ok"}
    assert Evaluator.evaluate(control, result) == "FAIL"
