import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime
from trace360.core.runner import Trace360Runner
from trace360.core.models import ControlDefinition, ControlSet
from trace360.core.registry import ConnectorRegistry

@pytest.fixture
def mock_stores():
    raw_store = MagicMock()
    raw_store.write.return_value = "gs://mock/uri"
    metadata_store = MagicMock()
    return raw_store, metadata_store

def test_runner_run_control(mock_stores):
    raw_store, metadata_store = mock_stores
    runner = Trace360Runner(raw_store, metadata_store)
    
    # Mock a collector
    mock_collector = MagicMock(return_value={"status": "ok", "iam_configuration": {"public_access_prevention": "enforced", "uniform_bucket_level_access": True}})
    ConnectorRegistry.register_collector("test_conn", "test_op")(mock_collector)
    
    # Mock a normalizer
    mock_normalizer = MagicMock(return_value={"public_access_prevention": "enforced", "uniform_bucket_level_access": True})
    ConnectorRegistry.register_normalizer("test_conn", "test_op")(mock_normalizer)
    
    control = ControlDefinition(
        id="C1", name="Test", connector="test_conn", operation="test_op",
        scope={"bucket_name": "b1"},
        expected={"public_access_prevention": "enforced"}
    )
    
    result = runner.run_control(control)
    
    if result.status == "ERROR":
        print(f"Error: {result.normalized_result.get('error')}")
    
    assert result.status == "PASS"
    assert result.control_id == "C1"
    raw_store.write.assert_called_once()
    metadata_store.write_evidence.assert_called_once()

def test_runner_run_control_set(mock_stores):
    raw_store, metadata_store = mock_stores
    runner = Trace360Runner(raw_store, metadata_store)
    
    # Use existing registrations from previous test or register again
    mock_collector = MagicMock(return_value={"status": "ok"})
    ConnectorRegistry.register_collector("test_conn", "set_op")(mock_collector)
    
    control_set = ControlSet(id="S1", name="Set 1", controls=["C1"])
    control = ControlDefinition(id="C1", name="C1", connector="test_conn", operation="set_op")
    
    run_record = runner.run_control_set(control_set, [control])
    
    assert run_record.status == "COMPLETED"
    assert run_record.total_controls == 1
    assert run_record.passed_count == 1
    assert metadata_store.write_run.call_count == 2 # Once for RUNNING, once for COMPLETED
