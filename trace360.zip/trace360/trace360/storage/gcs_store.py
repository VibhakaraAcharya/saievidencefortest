import json
from google.cloud import storage
from datetime import datetime

class GCSRawEvidenceStore:
    def __init__(self, bucket_name: str, project_id: str = None):
        self.bucket_name = bucket_name
        self.client = storage.Client(project=project_id)
        self.bucket = self.client.bucket(bucket_name)

    def write(self, run_id: str, control_id: str, payload: dict) -> str:
        """
        Write raw evidence to GCS and return the URI.
        Path format: runs/{run_id}/{control_id}_{timestamp}.json
        """
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        blob_name = f"runs/{run_id}/{control_id}_{timestamp}.json"
        blob = self.bucket.blob(blob_name)
        
        blob.upload_from_string(
            data=json.dumps(payload, indent=2),
            content_type="application/json"
        )
        
        return f"gs://{self.bucket_name}/{blob_name}"
