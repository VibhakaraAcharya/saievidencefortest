from sqlalchemy import create_engine, Column, String, DateTime, JSON, Integer, ARRAY
from sqlalchemy.orm import declarative_base, sessionmaker
from trace360.core.models import EvidenceRecord, RunRecord

Base = declarative_base()

class RunORM(Base):
    __tablename__ = "runs"
    run_id = Column(String, primary_key=True)
    started_at = Column(DateTime)
    ended_at = Column(DateTime)
    status = Column(String)
    control_set_id = Column(String)
    total_controls = Column(Integer)
    passed_count = Column(Integer)
    failed_count = Column(Integer)
    error_count = Column(Integer)

class EvidenceORM(Base):
    __tablename__ = "evidence"
    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String, index=True)
    collected_at = Column(DateTime)
    control_id = Column(String)
    connector = Column(String)
    operation = Column(String)
    resource_id = Column(String)
    status = Column(String)
    severity = Column(String)
    framework = Column(ARRAY(String))
    raw_evidence_uri = Column(String)
    normalized_result = Column(JSON)
    evidence_hash = Column(String)

class PostgresMetadataStore:
    def __init__(self, db_url: str):
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def write_run(self, run: RunRecord):
        session = self.Session()
        try:
            run_orm = RunORM(**run.model_dump())
            session.merge(run_orm)
            session.commit()
        finally:
            session.close()

    def write_evidence(self, evidence: EvidenceRecord):
        session = self.Session()
        try:
            evidence_orm = EvidenceORM(**evidence.model_dump())
            session.add(evidence_orm)
            session.commit()
        finally:
            session.close()
