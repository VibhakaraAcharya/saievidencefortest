# Import all connectors to ensure they are registered with the ConnectorRegistry
from .gcp import collector as gcp_collector, normalize as gcp_normalize
# Add others as they are implemented
