from typing import Dict, Any
from trace360.core.registry import ConnectorRegistry

@ConnectorRegistry.register_normalizer("gcp", "get_bucket_encryption")
def normalize_bucket_encryption(raw_payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize GCP bucket metadata into a canonical shape for evaluation.
    """
    return {
        "public_access_prevention": raw_payload.get("iam_configuration", {}).get("public_access_prevention"),
        "uniform_bucket_level_access": raw_payload.get("iam_configuration", {}).get("uniform_bucket_level_access"),
        "cmek_enabled": raw_payload.get("encryption", {}).get("default_kms_key_name") is not None,
        "encryption_mode": "customer-managed" if raw_payload.get("encryption", {}).get("default_kms_key_name") else "google-managed"
    }
