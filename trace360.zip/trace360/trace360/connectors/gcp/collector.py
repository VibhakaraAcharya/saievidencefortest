from typing import Dict, Any
from google.cloud import storage
from trace360.core.registry import ConnectorRegistry

@ConnectorRegistry.register_collector("gcp", "get_bucket_encryption")
def get_bucket_encryption(scope: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fetch encryption and access control settings for a GCP bucket.
    """
    project_id = scope.get("project_id")
    bucket_name = scope.get("bucket_name")
    
    if not bucket_name:
        raise ValueError("bucket_name is required in scope")

    client = storage.Client(project=project_id)
    bucket = client.get_bucket(bucket_name)
    
    # Raw payload from bucket properties
    payload = {
        "bucket_name": bucket.name,
        "location": bucket.location,
        "encryption": {
            "default_kms_key_name": bucket.default_kms_key_name
        },
        "iam_configuration": {
            "public_access_prevention": bucket.iam_configuration.public_access_prevention,
            "uniform_bucket_level_access": bucket.iam_configuration.uniform_bucket_level_access_enabled
        },
        "storage_class": bucket.storage_class,
        "time_created": bucket.time_created.isoformat() if bucket.time_created else None
    }
    
    return payload
