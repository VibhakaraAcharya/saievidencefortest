import click
import os
from dotenv import load_dotenv
from trace360.core.control_loader import ControlLoader
from trace360.core.runner import Trace360Runner
from trace360.storage.gcs_store import GCSRawEvidenceStore
from trace360.storage.postgres_store import PostgresMetadataStore
import trace360.connectors # Ensure registration

load_dotenv()

@click.group()
def cli():
    """Trace360 CLI for evidence collection."""
    pass

def get_runner():
    # Initialize storage
    gcs_bucket = os.getenv("GCP_EVIDENCE_BUCKET")
    gcp_project = os.getenv("GCP_PROJECT_ID")
    db_url = f"postgresql://{os.getenv('POSTGRES_USER')}:{os.getenv('POSTGRES_PASSWORD')}@{os.getenv('POSTGRES_HOST')}:{os.getenv('POSTGRES_PORT')}/{os.getenv('POSTGRES_DB')}"
    
    raw_store = None
    if gcs_bucket:
        raw_store = GCSRawEvidenceStore(gcs_bucket, gcp_project)
    
    metadata_store = PostgresMetadataStore(db_url)
    
    return Trace360Runner(raw_store, metadata_store)

@cli.command()
@click.option("--path", required=True, help="Path to the control YAML file.")
@click.option("--controls-dir", default="controls", help="Base directory for controls.")
def run_control(path, controls_dir):
    """Run a single control."""
    loader = ControlLoader(controls_dir)
    control = loader.load_control(path)
    
    runner = get_runner()
    click.echo(f"Running control: {control.name} ({control.id})...")
    
    result = runner.run_control(control)
    
    click.echo(f"Status: {result.status}")
    if result.status == "PASS":
        click.secho("PASSED", fg="green")
    elif result.status == "FAIL":
        click.secho("FAILED", fg="red")
    else:
        click.secho(f"ERROR: {result.normalized_result.get('error', 'Unknown error')}", fg="yellow")

@cli.command()
@click.option("--path", required=True, help="Path to the control set YAML file.")
@click.option("--controls-dir", default="controls", help="Base directory for controls.")
def run_control_set(path, controls_dir):
    """Run a set of controls."""
    loader = ControlLoader(controls_dir)
    control_set = loader.load_control_set(path)
    controls = loader.resolve_controls_in_set(control_set)
    
    runner = get_runner()
    click.echo(f"Running control set: {control_set.name} ({control_set.id})...")
    click.echo(f"Total controls: {len(controls)}")
    
    run_record = runner.run_control_set(control_set, controls)
    
    click.echo("-" * 20)
    click.echo(f"Run ID: {run_record.run_id}")
    click.echo(f"Status: {run_record.status}")
    click.echo(f"Passed: {run_record.passed_count}")
    click.echo(f"Failed: {run_record.failed_count}")
    click.echo(f"Errors: {run_record.error_count}")

if __name__ == "__main__":
    cli()
