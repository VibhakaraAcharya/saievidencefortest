import hashlib
import json
from typing import Any, Dict

def compute_evidence_hash(data: Dict[str, Any]) -> str:
    """Compute a SHA-256 hash of a dictionary."""
    encoded = json.dumps(data, sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()
