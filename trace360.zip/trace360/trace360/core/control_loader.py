import yaml
from pathlib import Path
from typing import List, Union
from .models import ControlDefinition, ControlSet

class ControlLoader:
    def __init__(self, controls_dir: str):
        self.controls_dir = Path(controls_dir)

    def load_control(self, path: Union[str, Path]) -> ControlDefinition:
        """Load a single control definition from a YAML file."""
        if not str(path).endswith(".yaml"):
            path = f"{path}.yaml"
        
        full_path = Path(path)
        if not full_path.is_absolute():
            full_path = self.controls_dir / full_path

        with open(full_path, "r") as f:
            data = yaml.safe_load(f)
        
        return ControlDefinition(**data)

    def load_control_set(self, path: Union[str, Path]) -> ControlSet:
        """Load a control set definition from a YAML file."""
        if not str(path).endswith(".yaml"):
            path = f"{path}.yaml"

        full_path = Path(path)
        if not full_path.is_absolute():
            full_path = self.controls_dir / "control_sets" / full_path

        with open(full_path, "r") as f:
            data = yaml.safe_load(f)

        return ControlSet(**data)

    def resolve_controls_in_set(self, control_set: ControlSet) -> List[ControlDefinition]:
        """Resolve all controls listed in a control set."""
        controls = []
        for control_path in control_set.controls:
            controls.append(self.load_control(control_path))
        return controls
