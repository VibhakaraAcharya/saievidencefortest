from typing import Dict, Callable, Any, Optional

class ConnectorRegistry:
    _instance = None
    _registry: Dict[str, Callable] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConnectorRegistry, cls).__new__(cls)
        return cls._instance

    @classmethod
    def register_collector(cls, connector: str, operation: str):
        """Decorator to register a collector function."""
        def decorator(func: Callable):
            key = f"collector:{connector}:{operation}"
            cls._registry[key] = func
            return func
        return decorator

    @classmethod
    def register_normalizer(cls, connector: str, operation: str):
        """Decorator to register a normalizer function."""
        def decorator(func: Callable):
            key = f"normalizer:{connector}:{operation}"
            cls._registry[key] = func
            return func
        return decorator

    @classmethod
    def get_collector(cls, connector: str, operation: str) -> Optional[Callable]:
        """Retrieve a collector function for a given connector and operation."""
        key = f"collector:{connector}:{operation}"
        return cls._registry.get(key)

    @classmethod
    def get_normalizer(cls, connector: str, operation: str) -> Optional[Callable]:
        """Retrieve a normalizer function for a given connector and operation."""
        key = f"normalizer:{connector}:{operation}"
        return cls._registry.get(key)

    @classmethod
    def list_registrations(cls):
        """List all registered connector/operation pairs."""
        return list(cls._registry.keys())
