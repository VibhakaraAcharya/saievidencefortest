from typing import Any, Dict, List
from .models import ControlDefinition

class Evaluator:
    @staticmethod
    def evaluate(control: ControlDefinition, normalized_result: Dict[str, Any]) -> str:
        """
        Evaluate normalized result against control expectations.
        Returns 'PASS', 'FAIL', or 'ERROR'.
        """
        try:
            expected = control.expected
            if not expected:
                return "PASS"  # No expectations defined, assume pass if collected successfully

            for key, expected_value in expected.items():
                if key not in normalized_result:
                    # If a required key is missing, it's a failure
                    return "FAIL"
                
                actual_value = normalized_result[key]
                if actual_value != expected_value:
                    return "FAIL"

            return "PASS"
        except Exception:
            return "ERROR"
