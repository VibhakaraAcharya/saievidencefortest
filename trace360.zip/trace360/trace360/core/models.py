from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class ControlDefinition(BaseModel):
    id: str
    name: str
    connector: str
    operation: str
    scope: Dict[str, Any] = Field(default_factory=dict)
    expected: Dict[str, Any] = Field(default_factory=dict)
    evaluation: Optional[Dict[str, Any]] = None
    evidence: Dict[str, Any] = Field(default_factory=dict)

class ControlSet(BaseModel):
    id: str
    name: str
    controls: List[str]  # List of paths or IDs
    schedule: Optional[Dict[str, Any]] = None

class EvidenceRecord(BaseModel):
    run_id: str
    collected_at: datetime
    control_id: str
    connector: str
    operation: str
    resource_id: str
    status: str  # PASS, FAIL, ERROR
    severity: str
    framework: List[str] = Field(default_factory=list)
    raw_evidence_uri: str
    normalized_result: Dict[str, Any]
    evidence_hash: str

class RunRecord(BaseModel):
    run_id: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    status: str  # RUNNING, COMPLETED, FAILED
    control_set_id: Optional[str] = None
    total_controls: int = 0
    passed_count: int = 0
    failed_count: int = 0
    error_count: int = 0
