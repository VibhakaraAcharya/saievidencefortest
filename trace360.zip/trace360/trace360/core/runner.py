import uuid
from datetime import datetime
from typing import List, Optional
from .models import ControlDefinition, ControlSet, EvidenceRecord, RunRecord
from .registry import ConnectorRegistry
from .evaluator import Evaluator
from .hashing import compute_evidence_hash

class Trace360Runner:
    def __init__(self, raw_store=None, metadata_store=None):
        self.raw_store = raw_store
        self.metadata_store = metadata_store
        self.registry = ConnectorRegistry()

    def run_control(self, control: ControlDefinition, run_id: str = None) -> EvidenceRecord:
        """Execute a single control and record evidence."""
        if not run_id:
            run_id = str(uuid.uuid4())

        collected_at = datetime.utcnow()
        collector = self.registry.get_collector(control.connector, control.operation)
        
        if not collector:
            return self._create_error_record(control, run_id, collected_at, f"Connector {control.connector}:{control.operation} not found")

        try:
            # 1. Collect
            raw_payload = collector(control.scope)
            
            # 2. Normalize
            normalizer = self.registry.get_normalizer(control.connector, control.operation)
            if normalizer:
                normalized_result = normalizer(raw_payload)
            else:
                normalized_result = raw_payload
            
            # 3. Evaluate
            status = Evaluator.evaluate(control, normalized_result)
            
            # 4. Hash
            evidence_hash = compute_evidence_hash(normalized_result)
            
            # 5. Store Raw
            raw_uri = ""
            if self.raw_store:
                raw_uri = self.raw_store.write(run_id, control.id, raw_payload)
            
            # 6. Create Record
            record = EvidenceRecord(
                run_id=run_id,
                collected_at=collected_at,
                control_id=control.id,
                connector=control.connector,
                operation=control.operation,
                resource_id=control.scope.get("resource_id", "unknown"),
                status=status,
                severity=control.evidence.get("severity", "low"),
                framework=control.evidence.get("framework", []),
                raw_evidence_uri=raw_uri,
                normalized_result=normalized_result,
                evidence_hash=evidence_hash
            )
            
            # 7. Store Metadata
            if self.metadata_store:
                self.metadata_store.write_evidence(record)
                
            return record

        except Exception as e:
            return self._create_error_record(control, run_id, collected_at, str(e))

    def run_control_set(self, control_set: ControlSet, controls: List[ControlDefinition]) -> RunRecord:
        """Execute a set of controls."""
        run_id = str(uuid.uuid4())
        started_at = datetime.utcnow()
        
        run_record = RunRecord(
            run_id=run_id,
            started_at=started_at,
            status="RUNNING",
            control_set_id=control_set.id,
            total_controls=len(controls)
        )
        
        if self.metadata_store:
            self.metadata_store.write_run(run_record)

        for control in controls:
            result = self.run_control(control, run_id)
            if result.status == "PASS":
                run_record.passed_count += 1
            elif result.status == "FAIL":
                run_record.failed_count += 1
            else:
                run_record.error_count += 1

        run_record.ended_at = datetime.utcnow()
        run_record.status = "COMPLETED"
        
        if self.metadata_store:
            self.metadata_store.write_run(run_record)
            
        return run_record

    def _create_error_record(self, control: ControlDefinition, run_id: str, collected_at: datetime, error_msg: str) -> EvidenceRecord:
        return EvidenceRecord(
            run_id=run_id,
            collected_at=collected_at,
            control_id=control.id,
            connector=control.connector,
            operation=control.operation,
            resource_id=control.scope.get("resource_id", "unknown"),
            status="ERROR",
            severity=control.evidence.get("severity", "low"),
            framework=control.evidence.get("framework", []),
            raw_evidence_uri="",
            normalized_result={"error": error_msg},
            evidence_hash=""
        )
